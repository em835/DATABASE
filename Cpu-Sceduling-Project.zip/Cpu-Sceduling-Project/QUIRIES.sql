-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `mydb` DEFAULT CHARACTER SET utf8 ;
USE `mydb` ;

-- -----------------------------------------------------
-- Table `mydb`.`Stream`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Stream` (
  `stream_id` INT NOT NULL AUTO_INCREMENT,
  `stream_name` VARCHAR(45) NULL,
  PRIMARY KEY (`stream_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`faculty`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`faculty` (
  `faculty_id` INT NOT NULL AUTO_INCREMENT,
  `faculty_name` VARCHAR(45) NULL,
  PRIMARY KEY (`faculty_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Department`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Department` (
  `department_id` INT NOT NULL AUTO_INCREMENT,
  `department_name` VARCHAR(45) NOT NULL,
  `faculty_faculty_id` INT NOT NULL,
  PRIMARY KEY (`department_id`),
  INDEX `fk_Department_faculty1_idx` (`faculty_faculty_id` ASC),
  CONSTRAINT `fk_Department_faculty1`
    FOREIGN KEY (`faculty_faculty_id`)
    REFERENCES `mydb`.`faculty` (`faculty_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Student`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Student` (
  `student_id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` VARCHAR(45) NOT NULL,
  `last_name` VARCHAR(45) NULL,
  `date_of_birth` VARCHAR(45) NULL,
  `gender` VARCHAR(45) NULL,
  `Stream_stream_id` INT NOT NULL,
  `Department_department_id` INT NOT NULL,
  PRIMARY KEY (`student_id`),
  INDEX `fk_Student_Stream_idx` (`Stream_stream_id` ASC),
  INDEX `fk_Student_Department1_idx` (`Department_department_id` ASC),
  CONSTRAINT `fk_Student_Stream`
    FOREIGN KEY (`Stream_stream_id`)
    REFERENCES `mydb`.`Stream` (`stream_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Student_Department1`
    FOREIGN KEY (`Department_department_id`)
    REFERENCES `mydb`.`Department` (`department_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Course`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Course` (
  `course_id` INT NOT NULL AUTO_INCREMENT,
  `course_title` VARCHAR(45) NULL,
  `course_code` VARCHAR(45) NULL,
  PRIMARY KEY (`course_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Grade`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Grade` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `student_id` INT NULL,
  `course_id` INT NULL,
  `score` VARCHAR(25) NULL,
  `Student_student_id` INT UNSIGNED NOT NULL,
  `Course_course_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Grade_Student1_idx` (`Student_student_id` ASC),
  INDEX `fk_Grade_Course1_idx` (`Course_course_id` ASC),
  CONSTRAINT `fk_Grade_Student1`
    FOREIGN KEY (`Student_student_id`)
    REFERENCES `mydb`.`Student` (`student_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Grade_Course1`
    FOREIGN KEY (`Course_course_id`)
    REFERENCES `mydb`.`Course` (`course_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Tuition`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Tuition` (
  `student_amount` INT NULL,
  `student_debt` INT NULL,
  `Student_student_id` INT UNSIGNED NOT NULL,
  INDEX `fk_Tuition_Student1_idx` (`Student_student_id` ASC),
  CONSTRAINT `fk_Tuition_Student1`
    FOREIGN KEY (`Student_student_id`)
    REFERENCES `mydb`.`Student` (`student_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Scholarship`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Scholarship` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `scholarship_name` VARCHAR(45) NULL,
  `amount` INT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Contact_Information`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Contact_Information` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `student_id` INT NULL,
  `email` VARCHAR(45) NULL,
  `phone_number` VARCHAR(45) NULL,
  `contact_address` TEXT NULL,
  `postal_address` TEXT NULL,
  `Student_student_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Contact_Information_Student1_idx` (`Student_student_id` ASC),
  CONSTRAINT `fk_Contact_Information_Student1`
    FOREIGN KEY (`Student_student_id`)
    REFERENCES `mydb`.`Student` (`student_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Emergency_Contact`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Emergency_Contact` (
  `contact_name` VARCHAR(80) NULL,
  `email` VARCHAR(80) NULL,
  `phone_number` VARCHAR(80) NULL,
  `contact_address` TEXT NULL)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Student_Scholarship`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Student_Scholarship` (
  `Student_student_id` INT UNSIGNED NOT NULL,
  `Scholarship_id` INT NOT NULL,
  INDEX `fk_Student_Scholarship_Student1_idx` (`Student_student_id` ASC),
  INDEX `fk_Student_Scholarship_Scholarship1_idx` (`Scholarship_id` ASC),
  CONSTRAINT `fk_Student_Scholarship_Student1`
    FOREIGN KEY (`Student_student_id`)
    REFERENCES `mydb`.`Student` (`student_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Student_Scholarship_Scholarship1`
    FOREIGN KEY (`Scholarship_id`)
    REFERENCES `mydb`.`Scholarship` (`id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `mydb`.`Student_Emergency_Contact`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `mydb`.`Student_Emergency_Contact` (
  `Emergency_Contact_Contact_id` VARCHAR(45) NOT NULL,
  `Student_student_id` INT UNSIGNED NOT NULL,
  INDEX `fk_Student_Emergency_Contact_Student1_idx` (`Student_student_id` ASC),
  CONSTRAINT `fk_Student_Emergency_Contact_Student1`
    FOREIGN KEY (`Student_student_id`)
    REFERENCES `mydb`.`Student` (`student_id`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;

-- inserts for stream 

INSERT INTO stream (stream_name) VALUES ('Fall Stream'); 
INSERT INTO stream (stream_name) VALUES ('Spring Stream');




-- inserts for faculty 

INSERT INTO `faculty` ( `faculty_name`) VALUES
('Engineering'),
('Bio Medical Sciences');

 
-- inserts for  departments
INSERT INTO department (department_name, faculty_faculty_id) VALUES ('Applied CHemistry', '1');
INSERT INTO department (department_name, faculty_faculty_id) VALUES ('Computer Engineering', '2');

-- inserts for  students

INSERT INTO `student` ( `first_name`, `last_name`, `date_of_birth`, `gender`, `Stream_stream_id`, `Department_department_id`) VALUES
('John ', 'Smith', '13th - 02-1980', 'Male', 1, 1),
('Joseph ', 'Blake', '13th - 02-1940', 'Male', 1, 1);


-- inserts for course

INSERT INTO `course` ( `course_title`, `course_code`) VALUES
('Science', 'SS 101');

-- inserts for grade 

INSERT INTO `grade` (`id`, `score`, `Student_student_id`, `Course_course_id`) VALUES
(1, '95', 1, 1);


-- inserts for contact information

INSERT INTO `contact_information` (`id`, `email`, `phone_number`, `contact_address`, `postal_address`, `Student_student_id`) VALUES
(1, 'test@test.com', '123456789', '21 Jump street', 9876, 1),
(2, 'test@test.com', '123456789', '21 Jump street', 2324, 2);


-- inserts for tuition 
INSERT INTO `tuition`(`student_amount`,`student_debt`, `Student_student_id`) VALUES
('1000','500',1);

-- inserts for Scholarship 
INSERT INTO `Scholarship`(`scholarship_name`, `amount`) VALUES
('NASA','600');

-- inserts for Emergency_Contact 
INSERT INTO `Emergency_Contact`(`contact_name`,`email`, `phone_number`,`contact_address`) VALUES
('Jhonny','Johnny@gmail.com','986235142','22 jump street');

-- inserts for Student_Scholarship 
INSERT INTO `Student_Scholarship`(`Student_student_id`, `Scholarship_id`) VALUES
('1','1');


-- inserts for Student_Emergency_Contact 
-- update query 


UPDATE student
SET first_name = 'jake', last_name = 'Bright'
WHERE student_id =1;


DELETE FROM contact_information WHERE student_id =2


